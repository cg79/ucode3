// += operator
debugger;

function add(x) {
    return x+1;
}

console.log(add(3));